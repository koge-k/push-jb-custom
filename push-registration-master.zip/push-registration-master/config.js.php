window.GoogleSamples = window.GoogleSamples || {};
window.GoogleSamples.Config = window.GoogleSamples.Config || {
  gcmAPIKey: '<?=getenv('GCM_SERVER_KEY');?>'
};